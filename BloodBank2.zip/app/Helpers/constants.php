
////type
//define('FAKE', 1);
//define('TRUSTED', 2);
